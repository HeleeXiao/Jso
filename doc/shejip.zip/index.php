<?php
// 指定允许其他域名访问  
header('Access-Control-Allow-Origin:*');  
// 响应类型  
header('Access-Control-Allow-Methods:GET');  
// 响应头设置  
header('Access-Control-Allow-Headers:x-requested-with,content-type'); 
// sleep(1);
$data = array(
	 array(
		'src'=>'img/list/xq1.jpg',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'1.44亿只是账面价值，这幅简笔画还影响了全世界',
		'create_at'=>'21小时前',
		'zan'=>1660,
		'hot'=>23
	),array(
		'src'=>'img/list/xq2.jpg',
		'like'=>'艹',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'中国首个自主研发的高铁「复兴号」，却遭到英美日网友激烈吐槽',
		'create_at'=>'14小时前',
		'zan'=>324,
		'hot'=>23
	), array(
		'src'=>'img/list/xq3.jpg',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'【重磅】2017红底那最佳设计奖全集，103件作品13%来自中国',
		'create_at'=>'2天前',
		'zan'=>3782,
		'hot'=>49
	), array(
		'src'=>'img/list/xq4.gif',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'这样的包装才配得上爱迪生发明的电灯泡',
		'create_at'=>'13小时前',
		'zan'=>227,
		'hot'=>19
	), array(
		'src'=>'img/list/xq5.gif',
		'like'=>'艹',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'10块钱和100000块钱的设计差别在哪里？',
		'create_at'=>'2天前',
		'zan'=>3631,
		'hot'=>87
	), array(
		'src'=>'img/list/xq6.jpg',
		'like'=>'艹',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'全世界都在读亚马逊推荐的这100本书，你读过几本？',
		'create_at'=>'2周前',
		'zan'=>3525,
		'hot'=>31
	), array(
		'src'=>'img/list/xq7.png',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'凌晨1:36，27岁的我死在办公司',
		'create_at'=>'3月前',
		'zan'=>9522,
		'hot'=>660
	), array(
		'src'=>'img/list/xq8.gif',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'机械的神奇原理？！11张动图带你揭秘',
		'create_at'=>'2年前',
		'zan'=>170937,
		'hot'=>5300
	),array(
		'src'=>'img/list/xq9.jpg',
		'like'=>'艹',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'【奇葩】这10款滑梯设计充分暴露了岛国人的脑洞',
		'create_at'=>'16小时前',
		'zan'=>305,
		'hot'=>13
	), array(
		'src'=>'img/list/xq10.jpg',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'世界那么大，李白杜甫在就走完了，还有人绘制了他们的旅行地图',
		'create_at'=>'2周前',
		'zan'=>2064,
		'hot'=>67
	),array(
		'src'=>'img/list/xq16.png',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'她做的镜面蛋糕能用来自拍，61万人喜欢，连小甜甜都来点赞',
		'create_at'=>'17小时前',
		'zan'=>348,
		'hot'=>99
	), array(
		'src'=>'img/list/xh.png',
		'like'=>'赞',
		'is_zan'=>1,//是否赞 1=赞 0=没有赞
		'title'=>'ofo小黄车牵手小黄人，真的要萌化了。',
		'create_at'=>'1年前',
		'zan'=>13615,
		'hot'=>142
	)
);

// echo json_encode( $data );
if(! isset($_GET['index']) || $_GET['index'] != 1){
	sleep(1);
}
echo json_encode(array( 'status'=>0,'message'=>'OK','result'=>$data ));