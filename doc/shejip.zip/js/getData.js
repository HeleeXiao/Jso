
// 以下是主体中的ajax请求
;
 var innerAjax = 1;
 // 先让数据默认请求出现一次
	$.ajax({ url: "http://yangsha.com?index=1",
		beforeSend:function(){},
		success: function(res){
			$('.loading').hide();
			res = eval( '(' + res + ')' );
	    	var html = "";
	    		if(res.status != 0 || res.message != "OK"){
					alert('数据请求失败');return false;
	    		}
	    		for (var i = res.result.length - 1; i >= 0; i--) {
	    			html +='<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 big-list">'
	    			html += '<div class="xs-box">'+res.result[i].like+'</div>'
		        	html +=  '<li class="list-li">';
					html +=   ' <img src="'+res.result[i].src+'" alt="" width="200" height="200">';
					html +=   '<a href="#" class="list-title">'+res.result[i].title+'</a>';
					html +=   '<p class="p-list">';
					html +=    '<span class="list-time">'+res.result[i].create_at+'</span>';
					html +=    '<span class="list-hot">'
					html +=    	    '<i class="i2"></i>'
					html +=     	'<span class="hot">'+res.result[i].hot+'</span>';
					html +=    '</span>'
					html +=    '<span class="list-zan">'
					html +=    	 	'<i class="i1"></i>'
					html +=     	'<span class="zan">'+res.result[i].zan+'</span>';
					html +=    '</span>'
					html +=   '</p>';
					html +=  '</li>';
					html += '</div>'
				}
			
			$("#list-box").append(html);
	  	}
	});

// 以下是控制数据只获取5组
$(window).scroll(function() {
        var awayBtm = $(document).height() - $(window).scrollTop() - $(window).height();
    // console.log('当前距离页面底部：' + awayBtm + 'px');
    //滚动条页面底部的最小距离为0的时候并且请求数据次数不超过五次
    if (awayBtm <= 0 && innerAjax <= 5) {
	    $.ajax({ url: "http://yangsha.com",
			beforeSend:function(){
				$('.loading').show();
			},
			success: function(res){
				innerAjax +=1;
				$('.loading').hide();
				res = eval( '(' + res + ')' );
		    	var html = "";
		    		if(res.status != 0 || res.message != "OK"){
						alert('数据请求失败');return false;
		    		}
		    		for (var i = res.result.length - 1; i >= 0; i--) {
	    			html +='<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 big-list">'
	    			html += '<div class="xs-box">'+res.result[i].like+'</div>'
		        	html +=  '<li class="list-li">';
					html +=   ' <img src="'+res.result[i].src+'" alt="" width="200" height="200">';
					html +=   '<a href="#" class="list-title">'+res.result[i].title+'</a>';
					html +=   '<p class="p-list">';
					html +=    '<span class="list-time">'+res.result[i].create_at+'</span>';
					html +=    '<span class="list-hot">'
					html +=    	    '<i class="i2"></i>'
					html +=     	'<span class="hot">'+res.result[i].hot+'</span>';
					html +=    '</span>'
					html +=    '<span class="list-zan">'
					html +=    	 	'<i class="i1"></i>'
					html +=     	'<span class="zan">'+res.result[i].zan+'</span>';
					html +=    '</span>'
					html +=   '</p>';
					html +=  '</li>';
					html += '</div>'
					}
				$("#list-box").append(html);
		  	}
		});
    }else{
    	console.log("innerAjax 等于 "+innerAjax+'了');
    }
});

