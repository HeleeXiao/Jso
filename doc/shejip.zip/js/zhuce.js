$('.jizhuwo-left').click(function(){
	$('.jizhuwo-left .i2').toggle();
})


$('.denglv form input:first').css('margin-top','15px')




function checkForm(){
			return  checkUser() && checkPwd() && checkEmail() && checkRepeat();
					
		}


// 以下是邮箱的正则验证
function blurOrSubmitCheckEmail(){
	var email=$.trim($('#email').val());
		var reg = /^[\w-]+@[0-9a-zA-Z]+(\.[a-z]+){1,3}$/;
	     if(email == ""){  
	           $(".youxiang").html('邮箱不能为空').css('color','red');
	           return false; 
	     }else if(!(reg.test(email))){  
	           $(".youxiang").html('邮箱格式错误').css('color','red');   
	           return false; 

	     }else{  
	           $(".youxiang").html('') 
	              
	           return true; 

	             
	        }  
}


// 以下是密码的正则验证
function blurOrSubmitCheckPwd(){
		var paw=$.trim($('#paw').val());
		var isReg = /^[a-zA-Z]\w{5,11}$/;
	     if(paw == ""){  
	           $(".mima").html('请输入密码').css('color','red');
	           return false; 
	     }else if(!(isReg.test(paw))){  
	           $(".mima").html('密码格式错误').css('color','red');   
	           return false; 

	     }else{  
	           $(".mima").html('')  
	           return true; 

	             
	        } 
}
// 以下是重复密码的验证
function blurOrSubmitCheckrepeat(){
	var repeat=$.trim($('#repaw').val());
	var paw=$('#paw').val();

	    if(repeat==''){
	    	$(".chongfu").html('请重复密码').css('color','red');
	    	console.log(1111111)
	    	return false;
	    }else if(repeat!=paw){
	    	$(".chongfu").html('密码输入不一致').css('color','red');
	    	console.log(22222)

	    	return false;

	    }else{
	    	$('.chongfu').html('')
	    	return true;
	    }
}



// 以下是登录名的正则验证
function blurOrSubmitCheckUser(){
	var user=$.trim($('#user').val());
		var reg = /^[a-zA-Z]\w{5,11}$/;
	     if(user == ""){  
	           $(".denglvming").html('用户名不能为空').css('color','red');
	           return false; 
	     }else if(!(reg.test(user))){  
	           $(".denglvming").html('请输入正确的用户名').css('color','red');   
	           return false; 

	     }else{  
	           $(".denglvming").html('') 
	              
	           return true; 

	             
	        }  
}
// 以下是失去焦点的方法调用
$('form input:first').blur(function(){
	blurOrSubmitCheckEmail();

})
$('form input:eq(1)').blur(function(){
	blurOrSubmitCheckPwd();

})
$('form input:eq(2)').blur(function(){
	blurOrSubmitCheckrepeat();

})

$('form input:last').blur(function(){
	blurOrSubmitCheckUser();

})

function checkEmail(){
	return blurOrSubmitCheckEmail();
}
function checkPwd(){
	return blurOrSubmitCheckPwd();
	
}
function checkRepeat(){
	return blurOrSubmitCheckrepeat();

}
function checkUser(){
	 return blurOrSubmitCheckUser();

}
