// 侧边导航的li标签 改变样式
$('.div-one ul li:gt(5)').not('.last')
						 .css({
						 	'font-size':'16px',
						 	'padding-left':'70px',
						 	'line-height':'38px'

							})
						

// 侧边导航的显示和隐藏
$('.div-one span').click(function(){
	$('.div-one ul').slideToggle(100);
})


// 点击出现搜索框的代码
$('.shousuo a:eq(1)').click(function(){
	$('.shousuo a:eq(1)').css('margin-left','-200px');
	$('.shousuo a:first').css('margin-left','-250px');
	$('.shousuo a:eq(2)').css({
		'display':'block',
		'margin-left':'-228px'
	})

	$('.shousuo input').css({
		'display':'block',
		'margin-left':'-202px'
	})
	$('.gongzuo a:first').css('margin-left','-240px');
	$('.gongzuo a:eq(1)').css('margin-left','-140px');
})


$('.shousuo a:eq(2)').click(function(){
	$('.shousuo a').css('margin-left','0px');

	$('.shousuo a:eq(2)').css('display','none');
	$('.shousuo input').css({
		'display':'none',
		'margin-left':'0px'
	})
	$('.gongzuo a').css('margin-left','0px');
})





$('.suiji li:not(:first)').css('margin-left','10px')

// 隐藏的导航栏距离上面的滚动距离到750显示
$(window).scroll(function(){ 
        var top = $(this).scrollTop(); // 当前窗口的滚动距离
     
      	if(top>750){
      		$('.nav-top').slideDown(200);
      	}else{
      		$('.nav-top').slideUp(200);

      	}
  });

// 二级导航小手划过的时候显示和隐藏
$('.erjidaohang').hover(function(){
	$('.erjidaohang ul').toggle();
})

/**
 * 投票样式
 */
$('.span-click').click(function(){
	//将自身(投票选项)的data-tplen 值赋值给button的data-tplen,
	 $('.vote button').data("tplen",$(this).data('tplen'));
	 $('.span-box').find('span').removeClass('toupiao');
	 $(this).find('span').first().addClass('toupiao');
	 // console.log($(this).data('tplen'));
});

// 点击让隐藏的进度条框出现
$('.vote button').click(function(){
	//判断是否选中且只选中了一个投票选项
	if($(".toupiao").length == 1)
	{
		$('.vote').hide();
		$('.jindu').show();
		//通过button的data-tplen的值找到相对应的进度条，
		$("#tplen-"+$(this).data('tplen')).width(
		   	$("#tplen-"+$(this).data('tplen')).width() + 50);
		$("#tp-num-"+$(this).data('tplen')).html(
			parseInt($("#tp-num-"+$(this).data('tplen')).html()) + 1
			)
	}else{
		alert("请选择有效的投票选项");
	}
})

/////////////////////////

$('.collection a:not(:first)').css('margin-left','20px');

// 小手划过微信图标 隐藏的二维码显示
$('.collection a:eq(2)').mouseenter(function(){
	$('.collection .erweima').show();
}).mouseleave(function(){
	$('.collection .erweima').hide()
})

// 点击弹出链接路径
$('.collection a:eq(3)').click(function(){
	prompt('按Ctrl+C或使用鼠标右键复制','http://www.shejipi.com/162606.html');
})


$('.fangwen img:not(:first)').css('margin-left','20px')


// 回到顶部图标的显示和隐藏
$(window).scroll(function(){
	var top=$(this).scrollTop();
	
      	if(top>750){
      		$('.home-top').show();
      	}else{
      		$('.home-top').hide();

      	}
})


// 点击回到顶部
$(function(){
  $(".home-top").click(function() {
      $("html,body").animate({scrollTop:0}, 500);
  }); 
 })


// 投票下隐藏的进度条宽度
$('.jindu li:first span').css('width','60%');
$('.jindu li:eq(1) span').css('width','25%');
$('.jindu li:eq(2) span').css('width','20%');
$('.jindu li:last span').css('width','10%');




// 点击input让div的高度改变  p标签里面的数字+1
$('.popularity li input').click(function(){
	   var height = $(this).prev().height() + 1;
	   $(this).prev().height(height).css('background-color','#DA4844');
	   var num=parseInt($(this).prev().prev().html())+1;
	    $(this).prev().prev().html(num);
	    $('.popularity input').css('pointer-events','none')
 });




$('.pinglun button').click(function(){
	var user=document.myform.user;
	var font=$("#font").val();
	var date=new Date();
	var h=date.getFullYear()
	var m=date.getMonth()+1;
	var d=date.getDate();
	var hour=date.getHours();
	var min=date.getMinutes();
	var times = h+'-'+m+'-'+ d + " " + hour+':'+min;

	var userinp=user.value;
	var html='';
	 html += '<div class="content">';
	html += '		<div class="yonghu">';
		html += '		<a href="#"><i></i></a>';
		html += '	</div>';
		html += '	<div class="reply">';
    	html += '		<div class="name">';
    	html += '			<div class="photo"><img src="img/yonghu6.jpg" alt=""></div>';
    	html += '			<div class="time"><a href="#">'+userinp+'</a><p>'+times+'</p></div>';
    	html += '			<div style="clear:both"></div>';
    	html += '		</div>';
    	html += '		<div class="huifu">';
	    html += '			<p>'+font+'</p>';
	    html += '			<a href="#">回复</a>';
    	html += '		</div>';
    	html += '	</div>';
    	html += '	<div style="clear:both"></div>';
	$('.liuyan').prepend(html);
	return false;
});


