
// 以下是控制侧边导航的代码
$('.div-one ul li:gt(5)').not('.last')
						 .css('font-size','16px')
						 .css('padding-left','70px')
						 .css('line-height','38px');
$('.div-one span').click(function(){
	$('.div-one ul').slideToggle(100);
})

// 以下是控制搜索框的代码
$('.shousuo a:eq(1)').click(function(){
	$('.shousuo a:eq(1)').css('margin-left','-200px');
	$('.shousuo a:first').css('margin-left','-250px');
	$('.shousuo a:eq(2)').css({
		'display':'block',
		'margin-left':'-228px'
	})

	$('.shousuo input').css({
		'display':'block',
		'margin-left':'-202px'
	})
	$('.gongzuo a:first').css('margin-left','-240px');
	$('.gongzuo a:eq(1)').css('margin-left','-140px');
})


$('.shousuo a:eq(2)').click(function(){
	$('.shousuo a').css('margin-left','0px');

	$('.shousuo a:eq(2)').css('display','none');
	$('.shousuo input').css({
		'display':'none',
		'margin-left':'0px'
	})
	$('.gongzuo a').css('margin-left','0px');
})
$('.suiji li:not(:first)').css('margin-left','4px')


// 以下是让top隐藏的导航栏 鼠标滚动750的时候出现
$(window).scroll(function(){ 
        var top = $(this).scrollTop(); // 当前窗口的滚动距离
     
      	if(top>750){
      		$('.nav-top').slideDown(200);
      	}else{
      		$('.nav-top').slideUp(200);

      	}
  });

// 以下是让top隐藏的二级导航小手划过的时候出现
$('.erjidaohang').hover(function(){
	$('.erjidaohang ul').toggle();
})

// 以下是让随机选择下隐藏的选择栏出现
$('.zuire').hover(function(){
	$('.zr-big1').toggle()
})
$('.reyi').hover(function(){
	$('.zr-big2').toggle()
})



// 以下是让回到顶部的图标鼠标滚动大于750的时候出现
$(window).scroll(function(){
	var top=$(this).scrollTop();
	
      	if(top>750){
      		$('.home-top').show();
      	}else{
      		$('.home-top').hide();

      	}
})

// 以下是回到顶部
$(function(){
  $(".home-top").click(function() {
      $("html,body").animate({scrollTop:0}, 500);
  }); 
 })

