
$('.div-one ul li:gt(5)').not('.last')
						 .css('font-size','16px')
						 .css('padding-left','70px')
						 .css('line-height','38px');
$('.div-one span').click(function(){
	$('.div-one ul').slideToggle(100);
})
// 以上是控制侧边导航的代码

$('.shousuo a:eq(1)').click(function(){
	$('.shousuo a:eq(1)').css('margin-left','-200px');
	$('.shousuo a:first').css('margin-left','-250px');
	$('.shousuo a:eq(2)').css({
		'display':'block',
		'margin-left':'-228px'
	})

	$('.shousuo input').css({
		'display':'block',
		'margin-left':'-202px'
	})
	$('.gongzuo a:first').css('margin-left','-240px');
	$('.gongzuo a:eq(1)').css('margin-left','-140px');
})


$('.shousuo a:eq(2)').click(function(){
	$('.shousuo a').css('margin-left','0px');

	$('.shousuo a:eq(2)').css('display','none',)
	$('.shousuo input').css({
		'display':'none',
		'margin-left':'0px'
	})
	$('.gongzuo a').css('margin-left','0px');
})



// 以上是控制搜索框的代码



$('.suiji li:not(:first)').css('margin-left','9px')

$(window).scroll(function(){ 
        var top = $(this).scrollTop(); // 当前窗口的滚动距离
     
      	if(top>750){
      		$('.nav-top').slideDown(200);
      	}else{
      		$('.nav-top').slideUp(200);

      	}
  });


$('.erjidaohang').hover(function(){
	$('.erjidaohang ul').toggle();
})

$('.zuire').hover(function(){
	$('.zr-big1').toggle()
})
$('.reyi').hover(function(){
	$('.zr-big2').toggle()
})




$(window).scroll(function(){
	var top=$(this).scrollTop();
	
      	if(top>750){
      		$('.home-top').show();
      	}else{
      		$('.home-top').hide();

      	}
})


$(function(){
  $(".home-top").click(function() {
      $("html,body").animate({scrollTop:0}, 500);
  }); 
 })


$('.suiji li').click(function(){
	$(this).addClass('active').siblings().removeClass('active');
})
$('.suiji .div1 a').each(function(){
	
})
// var h=$('.suiji .div1 a').html();
// console.log(h)



