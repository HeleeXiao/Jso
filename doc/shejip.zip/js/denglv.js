$('.jizhuwo-left').click(function(){
	$('.jizhuwo-left .i2').toggle();
})


function checkForm(){
			return  checkUser() && checkPwd() ;
					
		}

	function blurOrSubmitCheckUser(){
	var user=$.trim($('#user').val());
		var reg = /^[a-zA-Z]\w{5,11}$/;
	     if(user == ""){  
	           $(".dl").html('用户名不能为空').css('color','red');
	           return false; 
	     }else if(!(reg.test(user))){  
	           $(".dl").html('请输入正确的用户名').css('color','red');   
	           return false; 

	     }else{  
	           $(".dl").html('') 
	              
	           return true; 

	             
	        }  
}
function blurOrSubmitCheckPwd(){
		var paw=$.trim($('#paw').val());
		var isReg = /^[a-zA-Z]\w{5,11}$/;
	     if(paw == ""){  
	           $(".mima").html('请输入密码').css('color','red');
	           return false; 
	     }else if(!(isReg.test(paw))){  
	           $(".mima").html('密码格式错误').css('color','red');   
	           return false; 

	     }else{  
	           $(".mima").css('border','')  
	           return true; 

	             
	        } 
}


$('form input:first').blur(function(){
	blurOrSubmitCheckUser()

})

$('form input:last').blur(function(){
	blurOrSubmitCheckPwd()

})
function checkPwd(){
	return blurOrSubmitCheckPwd()
	
}
function checkUser(){
	 return blurOrSubmitCheckUser()

}



		