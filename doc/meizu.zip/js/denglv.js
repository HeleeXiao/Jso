
$('.inp1').click(function(){
	$('.guojia').slideToggle(100);
	 $('.guojia').animate({height:'250px',},"100");
	 $('.guojia').animate({width:'300px',},"100");

	
   
})



$('.guojia li').click(function(){
	// $(this).siblings().removeClass('active');
	// $(this).addClass('active').click(function(){
		$('.inp1 .shuzi').html($('.guojia li .right').html())
	})

// })

// $('.guojia li').click(function(){
// 	($('.inp1 .shuzi').html($('.guojia .li .right').html()))
// })
// console.log($('.guojia .li .right').html())
