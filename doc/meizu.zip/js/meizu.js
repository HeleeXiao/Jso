

$.fn.extend({

		})
		var i = 1;
		var p = null;
		var j = null;
		var timer = setInterval(show,3000);
		function show(){
			if(i > 5){
				i = 0;
			}
			//console.log(i);
			//控制图片
			imgControl(i);
			//控制span
			spanControl(i);

			i++;
		}

		function imgControl(n){
			$('.imglist img').eq(n)
							 //.addClass("active")
							 .finish()
							 .fadeIn('slow')
							 .parent('a')
							 .siblings()
							 .children('img')
							 .finish()
							 .fadeOut('slow')
							 //.removeClass('active');
		}
		function spanControl(n){
			$('.spanlist span').eq(n)
							   .addClass('active')
							   .siblings()
							   .removeClass('active');

		}

		//鼠标滑入的时候 定时停止
		$(".imglist").mouseenter(function(){
			clearInterval(timer);
			console.log(i);	
			p = i-2;
			j = i;
		}).mouseleave(function(){
			timer = setInterval(show,3000);
		})

		//给span 绑定鼠标滑入事件
		var index;
		$(".spanlist span").mouseenter(function(){
			//console.log($(this).index());
		 	index = $(this).index();
			imgControl(index);
			spanControl(index);
		}).mouseleave(function(){
			i = index+1;
		})

// 轮播图
$('.imglist img:eq(3)').css('margin-left','-550px')


//导航鼠标滑过
$('.daohang .out-li').mouseenter(function(){
	var dom = $(this).find(".shoujikuang li");
	$(this).css("overflow","visible");
	$(this).find("a").css('color','#15A7ED');
	$(this).siblings().find("a").css('color','black');
	for(var i = 0; i < dom.length; i++){
		var thisTime = 0.5 + 0.3　* i +"s";
		dom.eq(i).css({"transition":thisTime,"opacity":1,"margin-left":"-20px"});
	}

}).mouseleave(function(){
	$(this).css("overflow","hidden");
	$('.daohang .out-li').find("a").css('color','white');
	$(".shoujikuang li").css({"transition":"0s linear","opacity":0,"margin-left":0});
})


$(".daohang .out-li").mouseenter(function(){
	$(".backContain").slideDown();
	$(".logo img").attr('src','http://www3.res.meizu.com/static/cn/_partial/header/images/logo-new_294da7f.png');
}).mouseleave(function(){
	$(".backContain").hide();
	$(".logo img").attr('src','img/logo-new_774b3e9.png');
})
$(".shoujikuang li").mouseenter(function(){
	$(this).css({"transition":"0.5s linear","opacity":1}).siblings().css({"transition":"0.2s linear","opacity":0.4});
}).mouseleave(function(){
	$(".shoujikuang li").css({"transition":"0 linear","opacity":1});
})




$('.denglv').mouseenter(function(){
	// console.log('1232132312')
	$('.denglv .yincangdenglv').css('display','block');
}).mouseleave(function(){
	$('.denglv .yincangdenglv').css('display','none');
})
// 二级导航




$('.daohang li:eq(1)').mouseenter(function(){

	// $('.meizu-daohang2').css('display','block');
	$('.meizu-daohang2').slideToggle(500);
	$('meizu-daohang2 li').animate({left:'20px'}); 

}).mouseleave(function(){
	// $('.meizu-daohang2').css('display','none');
	$('.meizu-daohang2').slideToggle(500);


});


// ***点击回到顶部
$(function(){
  $(".back-top").click(function() {
      $("html,body").animate({scrollTop:0}, 500);
  }); 
 })


$(window).scroll(function(){
	var st=$(this).scrollTop();
	if(st>924){
		$('.back-top').css('display','block');
	}else{
		$('.back-top').css('display','none');
	}
})
// *****回到顶部结束*******

// ****二维码显示******
$('.footer-bottom .span2').mouseenter(function(){
	$('.erweima').css('display','block');
}).mouseleave(function(){
	$('.erweima').css('display','none');

})
// ****************************


// *****选择语言显示隐藏
$('.lang-button').click(function(){
	$('.lang-box').toggle();
	
})
// %%%%%%%%展示图片移动%%%%%%%%
// $('.left-key').click(function(){
// 	$('.img-box .hezi:eq(2)').animate({left:'-1400px'},1000)
// }),function(){
// 	$('.img-box .hezi:eq(2)').animate({left:'0px'},1000)

// }



// 888888888888888888888888888888






$('.left-key').click(function(){
		$('.hezi1').css({'margin-left':'-1240px','transition-duration':'1s'});
		$('.hezi2').css({'margin-left':'0px','transition-duration':'1s'});
});
		


$('.right-key').click(function(){
		$('.hezi1').css({'margin-left':'0px','transition-duration':'1s'});
		$('.hezi2').css({'margin-left':'1240px','transition-duration':'1s'});
});

$('.lang-guanbi').click(function(){
	$('.lang-box').css('display','none');
})
	
		

























// $('.left-key').click(function(){
// 		$('.hezi2').css({'margin-left':'-1240px','transition-duration':'1s'});
// 		$('.hezi3').css({'margin-left':'0px','transition-duration':'1s'});
// 		// $('.hezi1').css({'margin-left':'0px','transition-duration':'1s'});

			
// 		})



// $('.right-key').click(function(){
// 		$('.img-box .hezi1').css({'margin-left':'-1240px','transition-duration':'1s'});
// 		$('.img-box .hezi2').css({'margin-left':'0px','transition-duration':'1s'});
// 		$('.img-box .hezi2').css({'margin-left':'0px','transition-duration':'1s'})

			
// 		})

