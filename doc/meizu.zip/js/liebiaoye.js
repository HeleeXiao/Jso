//导航鼠标滑过
$('.daohang .out-li').mouseenter(function(){
	var dom = $(this).find(".shoujikuang li");
	$(this).css("overflow","visible");
	$(this).find("a").css('color','#15A7ED');
	$(this).siblings().find("a").css('color','black');
	for(var i = 0; i < dom.length; i++){
		var thisTime = 0.5 + 0.3　* i +"s";
		dom.eq(i).css({"transition":thisTime,"opacity":1,"margin-left":"-20px"});
	}

}).mouseleave(function(){
	$(this).css("overflow","hidden");
	$('.daohang .out-li').find("a").css('color','#333');
	$(".shoujikuang li").css({"transition":"0s linear","opacity":0,"margin-left":0});
})
$(".daohang .out-li").mouseenter(function(){
	$(".backContain").slideDown();
}).mouseleave(function(){
	$(".backContain").hide();
})
$(".shoujikuang li").mouseenter(function(){
	$(this).css({"transition":"0.5s linear","opacity":1}).siblings().css({"transition":"0.2s linear","opacity":0.4});
}).mouseleave(function(){
	$(".shoujikuang li").css({"transition":"0 linear","opacity":1});
})



// ***********轮播图*****************
$.fn.extend({

		})
		var i = 1;
		var p = null;
		var j = null;
		var timer = setInterval(show,3000);
		function show(){
			if(i > 4){
				i = 0;
			}
			//console.log(i);
			//控制图片
			imgControl(i);
			//控制span
			spanControl(i);

			i++;
		}

		function imgControl(n){
			$('.imglist img').eq(n)
							 //.addClass("active")
							 .finish()
							 .fadeIn('slow')
							 .parent('a')
							 .siblings()
							 .children('img')
							 .finish()
							 .fadeOut('slow')
							 //.removeClass('active');
		}
		function spanControl(n){
			$('.spanlist span').eq(n)
							   .addClass('active')
							   .siblings()
							   .removeClass('active');

		}

		//鼠标滑入的时候 定时停止
		$(".imglist").mouseenter(function(){
			clearInterval(timer);
			console.log(i);	
			p = i-2;
			j = i;
		}).mouseleave(function(){
			timer = setInterval(show,3000);
		})

		//给span 绑定鼠标滑入事件
		var index;
		$(".spanlist span").mouseenter(function(){
			//console.log($(this).index());
		 	index = $(this).index();
			imgControl(index);
			spanControl(index);
		}).mouseleave(function(){
			i = index+1;
		})
		//给两个按钮绑定事件
		$(".prev").click(function(){
				if(p < 0){
					p = 4;
				}
				imgControl(p);
				spanControl(p);
				p--;
				j = p+2;
		}).mouseleave(function(){
				i = p+1;
		})
		$(".next").click(function(){
			if(j > 4){
				j = 0;
			}
			imgControl(j);
			spanControl(j);
			j++;
			p = j-2;
		}).mouseleave(function(){
			i = j;
		})

		// ***********轮播图移动图标*************


		// *******侧边栏******

 
	$('.li1').mouseenter(function(){
		$(this).addClass('active').siblings().removeClass('active');
		$('.active .two-menu').css('display','block');
	}).mouseleave(function(){
		$('.active .two-menu').css('display','none');

	})
	


		// *****底部换图*****
		$('.a5').mouseenter(function(){
			$('.a5 img:eq(1)').toggle();
		}).mouseleave(function(){
			$('.a5 img:eq(1)').toggle();
		})

		$('.a6').mouseenter(function(){
			$('.a6 img:eq(1)').toggle();
		}).mouseleave(function(){
			$('.a6 img:eq(1)').toggle();
		})
		$('.a7').mouseenter(function(){
			$('.a7 img:eq(1)').toggle();
		}).mouseleave(function(){
			$('.a7 img:eq(1)').toggle();
		})
		$('.a8').mouseenter(function(){
			$('.a8 img:eq(1)').toggle();
		}).mouseleave(function(){
			$('.a8 img:eq(1)').toggle();
		})

// *************热门推荐
		$('.button1').click(function(){
			$('.button2').css('border','1px solid #efefef')
			$('.button2 p').css('color','#efefef')
			$('.button1').css('border','1px solid #999')
			$('.button1 p').css('color','#999')
			if($('.translation1').css('margin-left')=='-1240px')
			{
			$('.translation1').css({'margin-left':'0px','transition-duration':'1s'});
			$('.translation2').css({'margin-left':'1240px','transition-duration':'1s'});
			}
		})

		$('.button2').click(function(){
			$('.button1').css('border','1px solid #efefef')
			$('.button1 p').css('color','#efefef')
			$('.button2').css('border','1px solid #999')
			$('.button2 p').css('color','#9999')
			if($('.translation1').css('margin-left')=='0px')
			{
			$('.translation1').css({'margin-left':'-1240px','transition-duration':'1s'});
			$('.translation2').css({'margin-left':'0px','transition-duration':'1s'});
			}
		})
		setInterval(play,3000);
		function play(){
			if($('.translation1').css('margin-left')=='0px'){
				$('.translation1').css({'margin-left':'-1240px','transition-duration':'1s'});
				$('.translation2').css({'margin-left':'0px','transition-duration':'1s'});
				$('.button1').css('border','1px solid #efefef')
				$('.button1 p').css('color','#efefef')
				$('.button2').css('border','1px solid #999')
				$('.button2 p').css('color','#999')
			}else{
				$('.translation1').css({'margin-left':'0px','transition-duration':'1s'});
				$('.translation2').css({'margin-left':'1240px','transition-duration':'1s'});
				$('.button2').css('border','1px solid #efefef')
				$('.button2 p').css('color','#efefef')
				$('.button1').css('border','1px solid #999')
				$('.button1 p').css('color','#999')
			}
		}



// *************点击切换商品*****************
$('.shuma .top li').click(function(){
	$(this).addClass('qiehuan').siblings().removeClass('qiehuan');
})




$('.shuma .top li:first').click(function(){
	$('.shuma .bottom1').css('display','block');
	$('.shuma .bottom2').css('display','none')
	$('.shuma .bottom3').css('display','none')
	$('.shuma .bottom4').css('display','none')
	$('.shuma .bottom5').css('display','none')
	
})
$('.shuma .top li:eq(1)').click(function(){
	$('.shuma .bottom1').css('display','none');
	$('.shuma .bottom2').css('display','block')
	$('.shuma .bottom3').css('display','none')
	$('.shuma .bottom4').css('display','none')
	$('.shuma .bottom5').css('display','none')

})

$('.shuma .top li:eq(2)').click(function(){
	$('.shuma .bottom1').css('display','none')
	$('.shuma .bottom2').css('display','none')
	$('.shuma .bottom3').css('display','block')
	$('.shuma .bottom4').css('display','none')
	$('.shuma .bottom5').css('display','none')

	
})
$('.shuma .top li:eq(3)').click(function(){
	$('.shuma .bottom1').css('display','none');
	$('.shuma .bottom2').css('display','none');
	$('.shuma .bottom3').css('display','none');
	$('.shuma .bottom4').css('display','block');
	$('.shuma .bottom5').css('display','none');


})
$('.shuma .top li:eq(4)').click(function(){
	$('.shuma .bottom1').css('display','none');
	$('.shuma .bottom2').css('display','none');
	$('.shuma .bottom3').css('display','none');
	$('.shuma .bottom4').css('display','none');
	$('.shuma .bottom5').css('display','block');
})
// ************上面是第一个选项卡******************

$('.zhineng .top li').click(function(){
	$(this).addClass('qiehuan').siblings().removeClass('qiehuan');
})

$('.zhineng .top li:first').click(function(){
	$('.zhineng .bottom1').css('display','block');
	$('.zhineng .bottom2').css('display','none')
	$('.zhineng .bottom3').css('display','none')
	$('.zhineng .bottom4').css('display','none')
	$('.zhineng .bottom5').css('display','none')
	$('.zhineng .bottom6').css('display','none')
	$('.zhineng .bottom7').css('display','none')
	
})
$('.zhineng .top li:eq(1)').click(function(){
	$('.zhineng .bottom1').css('display','none');
	$('.zhineng .bottom2').css('display','block')
	$('.zhineng .bottom3').css('display','none')
	$('.zhineng .bottom4').css('display','none')
	$('.zhineng .bottom5').css('display','none')
	$('.zhineng .bottom6').css('display','none')
	$('.zhineng .bottom7').css('display','none')

})

$('.zhineng .top li:eq(2)').click(function(){
	$('.zhineng .bottom1').css('display','none')
	$('.zhineng .bottom2').css('display','none')
	$('.zhineng .bottom3').css('display','block')
	$('.zhineng .bottom4').css('display','none')
	$('.zhineng .bottom5').css('display','none')
	$('.zhineng .bottom6').css('display','none')
	$('.zhineng .bottom7').css('display','none')

	
})
$('.zhineng .top li:eq(3)').click(function(){
	$('.zhineng .bottom1').css('display','none');
	$('.zhineng .bottom2').css('display','none');
	$('.zhineng .bottom3').css('display','none');
	$('.zhineng .bottom4').css('display','block');
	$('.zhineng .bottom5').css('display','none');
	$('.zhineng .bottom6').css('display','none');
	$('.zhineng .bottom7').css('display','none');


})
$('.zhineng .top li:eq(4)').click(function(){
	$('.zhineng .bottom1').css('display','none');
	$('.zhineng .bottom2').css('display','none');
	$('.zhineng .bottom3').css('display','none');
	$('.zhineng .bottom4').css('display','none');
	$('.zhineng .bottom5').css('display','block');
	$('.zhineng .bottom6').css('display','none');
	$('.zhineng .bottom7').css('display','none');
})
$('.zhineng .top li:eq(5)').click(function(){
	$('.zhineng .bottom1').css('display','none');
	$('.zhineng .bottom2').css('display','none');
	$('.zhineng .bottom3').css('display','none');
	$('.zhineng .bottom4').css('display','none');
	$('.zhineng .bottom5').css('display','none');
	$('.zhineng .bottom6').css('display','block');
	$('.zhineng .bottom7').css('display','none');
})
$('.zhineng .top li:eq(6)').click(function(){
	$('.zhineng .bottom1').css('display','none');
	$('.zhineng .bottom2').css('display','none');
	$('.zhineng .bottom3').css('display','none');
	$('.zhineng .bottom4').css('display','none');
	$('.zhineng .bottom5').css('display','none');
	$('.zhineng .bottom6').css('display','none');
	$('.zhineng .bottom7').css('display','block');
})
// *****************上面是第二个选项卡*******************

$('.zhoubian .top li').click(function(){
	$(this).addClass('qiehuan').siblings().removeClass('qiehuan');
})




$('.zhoubian .top li:first').click(function(){
	$('.zhoubian .bottom1').css('display','block');
	$('.zhoubian .bottom2').css('display','none')
	$('.zhoubian .bottom3').css('display','none')
	
})
$('.zhoubian .top li:eq(1)').click(function(){
	$('.zhoubian .bottom1').css('display','none');
	$('.zhoubian .bottom2').css('display','block')
	$('.zhoubian .bottom3').css('display','none')

})

$('.zhoubian .top li:eq(2)').click(function(){
	$('.zhoubian .bottom1').css('display','none')
	$('.zhoubian .bottom2').css('display','none')
	$('.zhoubian .bottom3').css('display','block')

	
})
// $('.shouji-neirong .bottom li').mouseenter(function(){
// 	// $(this).css('box-shadow','0 0 30px rgba(34, 25, 25, 0.2) ')
// 	$(this).animate({top:2px}, 1000)
// }).mouseleavev(function(){
// 	// $(this).css('box-shadow','0px 0px 0px 0px')

// })

