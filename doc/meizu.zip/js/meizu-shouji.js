$.fn.extend({

		})
		var i = 1;
		var p = null;
		var j = null;
		var timer = setInterval(show,3000);
		function show(){
			if(i > 4){
				i = 0;
			}
			//console.log(i);
			//控制图片
			imgControl(i);
			//控制span
			spanControl(i);

			i++;
		}

		function imgControl(n){
			$('.imglist img').eq(n)
							 //.addClass("active")
							 .finish()
							 .fadeIn('slow')
							 .parent('a')
							 .siblings()
							 .children('img')
							 .finish()
							 .fadeOut('slow')
							 //.removeClass('active');
		}
		function spanControl(n){
			$('.spanlist span').eq(n)
							   .addClass('active')
							   .siblings()
							   .removeClass('active');

		}

		//鼠标滑入的时候 定时停止
		$(".imglist").mouseenter(function(){
			clearInterval(timer);
			console.log(i);	
			p = i-2;
			j = i;
		}).mouseleave(function(){
			timer = setInterval(show,3000);
		})

		//给span 绑定鼠标滑入事件
		var index;
		$(".spanlist span").mouseenter(function(){
			//console.log($(this).index());
		 	index = $(this).index();
			imgControl(index);
			spanControl(index);
		}).mouseleave(function(){
			i = index+1;
		})

// 轮播图

$(".sc1").click(function(){

if($(".sc-1").css("display")=="none"){

$(".sc-1").css('display','block');

}else{

$(".sc-1").css('display','none');

}

});

$(".sc2").click(function(){

if($(".sc-2").css("display")=="none"){

$(".sc-2").css('display','block');
$(".footer .sc-2 a").css('transition','all .5s .5s linar')

}else{

$(".sc-2").css('display','none');

}

});

$(".sc3").click(function(){

if($(".sc-3").css("display")=="none"){

$(".sc-3").css('display','block');

}else{

$(".sc-3").css('display','none');

}

});



$(".lang").click(function(){

if($(".YC-lang").css("display")=="none"){

$(".YC-lang").css('display','block');

}else{

$(".YC-lang").css('display','none');

}

});