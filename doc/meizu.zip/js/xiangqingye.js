//导航鼠标滑过
$('.daohang .out-li').mouseenter(function(){
	var dom = $(this).find(".shoujikuang li");
	$(this).css("overflow","visible");
	$(this).find("a").css('color','#15A7ED');
	$(this).siblings().find("a").css('color','black');
	for(var i = 0; i < dom.length; i++){
		var thisTime = 0.5 + 0.3　* i +"s";
		dom.eq(i).css({"transition":thisTime,"opacity":1,"margin-left":"-20px"});
	}

}).mouseleave(function(){
	$(this).css("overflow","hidden");
	$('.daohang .out-li').find("a").css('color','#333');
	$(".shoujikuang li").css({"transition":"0s linear","opacity":0,"margin-left":0});
})
$(".daohang .out-li").mouseenter(function(){
	$(".backContain").slideDown();
}).mouseleave(function(){
	$(".backContain").hide();
})
$(".shoujikuang li").mouseenter(function(){
	$(this).css({"transition":"0.5s linear","opacity":1}).siblings().css({"transition":"0.2s linear","opacity":0.4});
}).mouseleave(function(){
	$(".shoujikuang li").css({"transition":"0 linear","opacity":1});
})

// **********点击图片换掉********
$('.phone-img').click(function(){
	$("#big-img").attr('src',$(this).data('src'));
	$(this).parent().addClass('active')
							 .siblings()
							 .removeClass('active');
})

// ￥￥￥￥￥￥￥￥分类框￥￥￥￥￥￥￥￥￥￥￥
	
$('.xinghao a:first').css('border','1px solid #00c3f5');
$('.yanse a:eq(2)').css('border','1px solid #00c3f5');
$('.neicun a:first').css('border','1px solid #00c3f5');
$('.taocan a:first').css('border','1px solid #00c3f5');

$('.right a').click(function(){
	$(this).addClass('a-border').siblings().removeClass('a-border');
	$('.xinghao a:first').css('border','');
	$('.yanse a:eq(2)').css('border','');
	$('.neicun a:first').css('border','');
	$('.taocan a:first').css('border','');
})

// ***********点击更换图片**********


// ***********详情页切换***********
$('.zhuti-zhanshi li').click(function(){
	$(this).addClass('hengxian').siblings().removeClass('hengxian');

})
$('.zhuti-zhanshi li:first').click(function(){
	$('.xiangqing').css('display','block');
	$('.center-table').css('display','none');
	$('.huida').css('display','none')
	$('.dibu').css('margin-top','30px')

})
$('.zhuti-zhanshi li:eq(1)').click(function(){
	$('.center-table').css('display','block');
	$('.xiangqing').css('display','none');
	$('.huida').css('display','none');
	$('.dibu').css('margin-top','120px');
})
$('.zhuti-zhanshi li:eq(2)').click(function(){
	$('.huida').css('display','block');
	$('.center-table').css('display','none');
	$('.xiangqing').css('display','none');
	$('.dibu').css('margin-top','80px');

	
})



$('.a5').mouseenter(function(){
	$('.a5 img:eq(1)').toggle();
}).mouseleave(function(){
	$('.a5 img:eq(1)').toggle();
})

$('.a6').mouseenter(function(){
	$('.a6 img:eq(1)').toggle();
}).mouseleave(function(){
	$('.a6 img:eq(1)').toggle();
})
$('.a7').mouseenter(function(){
	$('.a7 img:eq(1)').toggle();
}).mouseleave(function(){
	$('.a7 img:eq(1)').toggle();
})
$('.a8').mouseenter(function(){
	$('.a8 img:eq(1)').toggle();
}).mouseleave(function(){
	$('.a8 img:eq(1)').toggle();
})

// **********回到顶部*************
$(function(){
  $(".why div:eq(1)").click(function() {
      $("html,body").animate({scrollTop:0}, 500);
  }); 
 })

$(window).scroll(function(){
	var st=$(this).scrollTop();
	if(st>300){
		$('.why').css('display','block');
	}else{
		$('.why').css('display','none');

	}
})

// %%%%%%%%%%%%%显示隐藏导航%%%%%%%%%%%%%%
$(window).scroll(function(){
	var st=$(this).scrollTop();
	if(st>300){
	setTimeout(function(){
   		$(".nav-YC").show("slow");
		},500);
	}else{
		$('.nav-YC').animate(1000).css('display','none')
		
	}
})
$(window).scroll(function(){
	var ul=$(this).scrollTop();

	if(ul>800){
		$('.yc-ul').css('visibility','visible');
	}else{
		$('.yc-ul').css('visibility','hidden');

	}
});


$('.yc-ul li').click(function(){
	$(this).addClass('yc-border').siblings().removeClass('yc-border');

})
$('.yc-ul li:first').click(function(){
	$('.xiangqing').css('display','block');
	$('.center-table').css('display','none');
	$('.huida').css('display','none')
	$('.dibu').css('margin-top','30px')


})
$('.yc-ul li:eq(1)').click(function(){
	$('.center-table').css('display','block');
	$('.xiangqing').css('display','none');
	$('.huida').css('display','none');
	$('.dibu').css('margin-top','120px');
})
$('.yc-ul li:eq(2)').click(function(){
	$('.huida').css('display','block');
	$('.center-table').css('display','none');
	$('.xiangqing').css('display','none');
	$('.dibu').css('margin-top','80px');

	
})



