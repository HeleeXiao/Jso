

$('.inp1').click(function(){
	$('.guojia').slideToggle(100);
	  $('.guojia').animate({height:'250px',},"500");
	 $('.guojia').animate({width:'300px',},"slow");
   
})
$('.guojia li').click(function(){
	// $(this).children().last()
	($('.inp1 .shuzi').html())
	console.log($('.guojia .right').each().html());
})
// ************账号登录 验证码登录切换************

$('.denglv').click(function(){

	$(this).addClass('huanse');
	$('.color').removeClass('huanse')
	$('.yanzhengdenglv').css('display','none');
	$('.yanzheng').css('display','block')


});
$('.color').click(function(){
	$(this).addClass('huanse');
	$('.denglv').removeClass('huanse');
	$('.yanzhengdenglv').css('display','block');
	$('.yanzheng').css('display','none')
	
})
