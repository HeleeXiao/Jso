$('.imglist img:eq(3)').css('margin-left','-550px')


$('.daohang a').mouseenter(function(){
	$(this).css('color','#15A7ED')
}).mouseleave(function(){
	$(this).css('color','#B9B9CE')
})


$('.denglv').mouseenter(function(){
	// console.log('1232132312')
	$('.denglv .yincangdenglv').css('display','block');
}).mouseleave(function(){
	$('.denglv .yincangdenglv').css('display','none');
})
// 二级导航


$('daohang .li1').mouseenter(function(){

	$('.meizu-daohang2').css('display','block');
});